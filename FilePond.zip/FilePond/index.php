<?php
define("LOTTOK", "./LottoCSV");
if (isset($_POST["ok"]))
{
    if (isset($_FILES["file"]) && $_FILES["file"]["error"] == 0)
    {
        $mime = finfo_file(finfo_open(FILEINFO_MIME_TYPE), $_FILES["file"]["tmp_name"]);
        if ($mime == "text/plain")
        {

            if (move_uploaded_file($_FILES["file"]["tmp_name"], LOTTOK . "/" . $_FILES["file"]["name"]))
            {
                $result["success"] = true;
                $result["info"] = "A fájl feltöltése sikeres!";
            } else
            {
                $result["success"] = false;
                $result["info"] = "A fájl feltöltése meghiúsult!";
            }
        } else
        {
            $result["success"] = false;
            $result["info"] = "Nem megfelelő a fájl típusa!";
        }
    } else
    {
        $result["success"] = false;
        $result["info"] = "Nincs fájl kiválasztva!";
    }
}
if (isset($_POST["ertek"]))
{
    if (isset($_POST["valaszto"]) && file_exists(LOTTOK . "/" . htmlspecialchars($_POST["valaszto"])))
    {
        $csv = fopen(LOTTOK . "/" . htmlspecialchars($_POST["valaszto"]), "r");
        $szamok = [];
        $potSzamok = [];
        $counter = 0;
        if (count(fgetcsv($csv, null, ";")) < 19)
        {
            rewind($csv);
            $lotto = 5;

            for ($j = 0; $j < 90; $j++)
            {
                $szamok[$j + 1] = 0;
            }
            while (!feof($csv))
            {
                $csvRow = fgetcsv($csv, null, ";");

                if ($csvRow === false)
                {
                    continue;
                }
                $darab = count($csvRow);
                for ($i = $darab - 5; $i < $darab; $i++)
                {

                    if (!empty($csvRow[$i]) && is_numeric($csvRow[$i]))
                    {
                        $szamok[$csvRow[$i]]++;
                    } else
                    {
                        $muti["hiba"] = "Hibás vagy üres érték a {$counter} sornak az {$i}  indexnél: " . json_encode($csvRow[$i]);
                    }
                }
                $counter++;
            }
        } elseif (count(fgetcsv($csv, null, ";")) == 19)
        {
            for ($j = 0; $j < 45; $j++)
            {
                $szamok[$j + 1] = 0;
            }
            rewind($csv);
            $lotto = 6;

            while (!feof($csv))
            {
                $csvRow = fgetcsv($csv, null, ";");

                if ($csvRow === false)
                {
                    continue;
                }

                $darab = count($csvRow);
                $eleje = $darab - 6;

                if ($csvRow[0] <= 2007 && $csvRow[1] <= 29)
                {
                    $eleje = $darab - 7;
                }

                for ($i = $eleje; $i < $darab; $i++)
                {
                    if (!empty($csvRow[$i]) && is_numeric($csvRow[$i]))
                    {
                        $szamok[$csvRow[$i]]++;
                    } else
                    {
                        $muti["hiba"] = "Hibás vagy üres érték a {$counter} sornak az {$i}  indexnél: " . json_encode($csvRow[$i]);
                    }
                }
                $counter++;
            }
        } else
        {
            $lotto = 7;

            for ($h = 0; $h < 12; $h++)
            {
                $potSzamok[$h + 1] = 0;
            }
            for ($j = 0; $j < 50; $j++)
            {
                $szamok[$j + 1] = 0;
            }

            while (!feof($csv))
            {
                $csvRow = fgetcsv($csv, null, ";");

                if ($csvRow === false)
                {
                    continue;
                }
                $darab = count($csvRow);
                for ($i = $darab - $lotto; $i < $darab; $i++)
                {

                    if (!empty($csvRow[$i]) && is_numeric($csvRow[$i]))
                    {
                        if ($i < $darab - 2)
                        {
                            $szamok[$csvRow[$i]]++;
                        } else
                        {
                            $potSzamok[$csvRow[$i]]++;
                        }
                    } else
                    {
                        $muti["hiba"] = "Hibás vagy üres érték a {$counter} sornak az {$i}  indexnél: " . json_encode($csvRow[$i]);
                    }
                }
                $counter++;
            }
        }

        fclose($csv);

        if (max($szamok) != 0)
        {
            if ($lotto != 7)
            {
                arsort($szamok);
                $legnagyobbSzamok = array_slice($szamok, 0, $lotto, true);
            } else
            {
                if (max($potSzamok) != 0)
                {
                    arsort($szamok);
                    arsort($potSzamok);
                    $legnagyobbNemPotSzamok = array_slice($szamok, 0, 5, true);
                    $legnagyobbPotSzamok = array_slice($potSzamok, 0, 2, true);
                } else
                {
                    $result["success"] = false;
                    $result["info"] = "A kiválaszott csv fájlban nincsennek meg a kellő adatok, ezért nem értelmezhető eredmény!";
                }
            }
        } else
        {
            $result["success"] = false;
            $result["info"] = "A kiválaszott csv fájlban nincsennek meg a kellő adatok, ezért nem értelmezhető eredmény!";
        }
    } else
    {
        $result["success"] = false;
        $result["info"] = "Nem létezik a kiválaszott fájl!";
    }
}
if (isset($_POST["torles"]))
{
    if (isset($_POST["valaszto"]) && file_exists(LOTTOK . "/" . htmlspecialchars($_POST["valaszto"])))
    {
        unlink(LOTTOK . "/" . htmlspecialchars($_POST["valaszto"]));
        $result["success"] = true;
        $result["info"] = "A kiválasztott fájl törlése sikeresen megtörtént!";
    } else
    {
        $result["success"] = false;
        $result["info"] = "Nem létezik a kiválaszott fájl!";
    }
}
?>
<!DOCTYPE html>
<html lang="hu">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Lottó Eredmények</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://unpkg.com/filepond/dist/filepond.css" rel="stylesheet">
        <link href="style.css" rel="stylesheet">
    </head>
    <body>
        <header>
            <div id="headerKozep">
                <div><h1>Lottó statisztikák</h1></div>
            </div>
        </header>
        <div class="container main">
            <?php
            if (isset($result))
            {
                print("<div class=\"card " . ($result["success"] ? "text-bg-success" : "text-bg-danger") . " fw-bold my-3\">" . $result["info"] . "</div>");
            }
            ?>
            <div class="card mt-3">
                <h2 class="m-3">Fájl feltöltése</h2>
                <form method="post"  enctype="multipart/form-data">
                    <div class="dropKozep"><div id="dropZone"><input type="file" class="filepond" name="file" accept=".csv" required /></div></div>
                    <input type="submit" name="ok" value="Feltöltés" class="btn btn-success m-3">
                </form>
            </div>
            <div class="card my-1">
                <h2 class="m-3">Feltöltött fájl kezelése</h2>
                <div class="form-group m-3">
                    <form method="post" >
                        <label class="form-label m-3" for="valaszto">Feltöltött fájlok: </label>
                        <select class="form-select " id="valaszto" name="valaszto">
                            <option selected value="Nincs">Nincs kiválasztva</option>
                            <?php
                            $folder = opendir(LOTTOK);
                            $files = glob(LOTTOK . "/*.csv");
                            foreach ($files as $file)
                            {
                                print("<option value=\"" . basename($file) . "\">" . basename($file) . "</option>\n");
                            }
                            ?>
                        </select>
                        <input type="submit" name="torles" value="Törlés" class="btn btn-danger m-3">
                        <input type="submit" name="ertek" value="Kiértékelés" class="btn btn-dark my-3">
                        </div>
                    </form>
                </div>
                <?php
                if (isset($legnagyobbSzamok) || (isset($legnagyobbNemPotSzamok) && isset($legnagyobbPotSzamok)))
                {
                    print("<div class=\"card card-yellow my-2\"><div class=\"m-3\">"
                            . "<h2 class=\"text-center m-3\">" . ($lotto == 5 ? "Az ötös lottón" : ($lotto == 6 ? "A hatos lottón" : "Az Eurojackpoton(5 + 2 pótszám)"))
                            . "  leggyakrabban húzott számok</h2>"
                            . "<table class=\"table border-dark table-danger table-hover \">"
                            . "<tr class=\"border border-dark\"><th class=\"border border-dark text-center\">#</th>");
                    if ($lotto != 7)
                    {
                        foreach ($legnagyobbSzamok as $key => $value)
                        {
                            print("<th class=\"border border-dark text-center\"> {$key} </th>");
                        }
                    } else
                    {
                        foreach ($legnagyobbNemPotSzamok as $key => $value)
                        {
                            print("<th class=\"border border-dark text-center\"> {$key} </th>");
                        }
                        foreach ($legnagyobbPotSzamok as $key => $value)
                        {
                            print("<th class=\"border border-dark text-center\"> {$key} </th>");
                        }
                    }
                    print("</tr><tr class=\"border border-dark\"><td class=\"border border-dark text-center\">Hányszor volt kihúzva:</td>");
                    if ($lotto != 7)
                    {
                        foreach ($legnagyobbSzamok as $key => $value)
                        {
                            print("<td class=\"border border-dark text-center\"> {$value} </td>");
                        }
                    } else
                    {
                        foreach ($legnagyobbNemPotSzamok as $key => $value)
                        {
                            print("<td class=\"border border-dark text-center\"> {$value} </td>");
                        }
                        foreach ($legnagyobbPotSzamok as $key => $value)
                        {
                            print("<td class=\"border border-dark text-center\"> {$value} </td>");
                        }
                    }
                    print("</tr></table></div></div>");
                }
                ?>
            </div>
            <?php
            if (isset($muti))
            {
                foreach ($muti as $key => $value)
                {
                    print($value . "<br>");
                }
            }
            ?>
            <footer>
                <div id="footerKozep">
                    <div><p>© 2024 Minden jog fenntartva</p></div>
                </div>
            </footer>
            <script src="https://unpkg.com/filepond/dist/filepond.js"></script>
            <script>
                const inputElement = document.querySelector('input[type="file"]');
                FilePond.create(inputElement, {
                    storeAsFile: true
                });
            </script>
    </body>
</html>